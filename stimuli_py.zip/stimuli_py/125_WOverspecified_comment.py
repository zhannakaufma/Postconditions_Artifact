def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace, if no
    whitespaces exists in the text you should split on commas ',' if no commas
    exists you should return the number of lower-case letters with odd order in
    the alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3
    """

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(",", " ").split()
    else:
        return len([i for i in txt if i.islower() and ord(i) % 2 == 0])


# The postcondition assert checks that the return value is either a list
# containing only strings without spaces or commas, or an integer between 0 and
# 13.

assert (
    all(
        isinstance(word, str) and " " not in word and "," not in word
        for word in return_value
    )
    if isinstance(return_value, list)
    else 0 <= return_value <= 13
)
