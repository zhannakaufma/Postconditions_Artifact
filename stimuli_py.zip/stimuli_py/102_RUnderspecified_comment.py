def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# Confirms that the return value is between x and y inclusively, but only if
# it's an even number; otherwise, it must be -1.

assert return_value == (
    max(i for i in range(x, y + 1) if i % 2 == 0)
    if x <= y and any(i % 2 == 0 for i in range(x, y + 1))
    else -1
)
