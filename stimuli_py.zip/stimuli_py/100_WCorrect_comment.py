def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2 * i for i in range(n)]


# Asserts that the return value is a list of length n starting with n, where
# each subsequent element increases by 2 if its index has the same parity as n, or
# by 1 otherwise.

assert (
    len(return_value) == n
    and return_value[0] == n
    and all(
        return_value[i] == return_value[i - 1] + (2 if i % 2 == n % 2 else 1)
        for i in range(1, n)
    )
)
