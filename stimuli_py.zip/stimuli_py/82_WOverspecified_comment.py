def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# The function checks if the return value is True and if all the string lengths
# divided by a range of numbers from 2 to the square root of the string length
# plus 1 give a remainder. If this condition is not met, it checks if the return
# value is False and if all the string lengths divided by a range of numbers from
# 2 to the square root of the string length plus 1 result in no remainder. The
# length of the string must be greater than 1.

assert (
    return_value
    and all(len(string) % i for i in range(2, int(len(string) ** 0.5) + 1))
    and len(string) > 1
) or (
    not return_value
    and not all(len(string) % i for i in range(2, int(len(string) ** 0.5) + 1))
)
