def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# Checks if the total elements in the list is odd and if so, verifies that the
# return value is unique in the list 'l' and is the middle value in the sorted
# list 'l'. If even, ensures the return value is the average of the two middle
# values.

assert (
    l.count(return_value) == 1
    and len([i for i in l if i < return_value])
    == len([i for i in l if i > return_value])
) or (
    len([i for i in l if i <= return_value])
    == len([i for i in l if i >= return_value])
)
