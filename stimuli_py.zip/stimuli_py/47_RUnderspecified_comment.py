def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# The median value returned is greater than or equal to at least half of the
# elements in the list

assert (
    sum(i <= return_value for i in l) >= len(l) // 2
    and sum(i >= return_value for i in l) >= len(l) // 2
)
