from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """Check if in given list of numbers, are any two numbers closer to each
    other than given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """

    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                distance = abs(elem - elem2)
                if distance < threshold:
                    return True

    return False


# The postcondition assert checks that the function's returned value is False.
# Or, if the function's returned value is True, then there exists a pair of non-
# equal values in the numbers list such that the absolute difference between them
# must be less than the defined 'threshold'.

assert not return_value or any(
    abs(j - i) < threshold for i in numbers for j in numbers if i != j
)
