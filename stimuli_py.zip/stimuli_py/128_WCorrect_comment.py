def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    if not arr:
        return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


# This postcondition checks that if all elements of the input list are positive
# or zero, the return value is non-negative. If there is at least one negative
# element in the list, the return value is non-positive. If the input list is
# empty, the return value is None.

assert (
    (all(x >= 0 for x in arr) and return_value >= 0)
    or (any(x < 0 for x in arr) and return_value <= 0)
    or (len(arr) == 0 and return_value is None)
)
