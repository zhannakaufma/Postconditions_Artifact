def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa,
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """

    flg = 0
    idx = 0
    new_str = list(s)
    for i in s:
        if i.isalpha():
            new_str[idx] = i.swapcase()
            flg = 1
        idx += 1
    s = ""
    for i in new_str:
        s += i
    if flg == 0:
        return s[len(s) :: -1]
    return s


# Guarantee that after processing the input string, all letters have been
# swapped in case if present, non-letter characters remain unchanged, and the
# string is reversed if there were no letters

assert all(
    (c.isalpha() and c.swapcase() == r) or (not c.isalpha() and c == r)
    for c, r in zip(s, return_value)
)
