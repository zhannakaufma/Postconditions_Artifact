def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2 * i for i in range(n)]


# Check that the length of the return value is the same as the input n and that
# each element is calculated by adding 2 times the index i to the input number n.

assert (
    all(return_value[i] == return_value[i - 1] + 2 for i in range(1, n))
    and len(return_value) == n
)
