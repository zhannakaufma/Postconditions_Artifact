def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    return set(s0) == set(s1)


# If the return value is True, it ensures that no character is present in one
# input string that is not present in the other input string.

assert (
    return_value == True
    and all(c in s1 for c in set(s0))
    and all(c in s0 for c in set(s1))
) or (
    return_value == False
    and not (all(c in s1 for c in set(s0)) and all(c in s0 for c in set(s1)))
)
