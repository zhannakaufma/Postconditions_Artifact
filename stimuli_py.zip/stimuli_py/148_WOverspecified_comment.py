def bf(planet1, planet2):
    """
    There are eight planets in our solar system: the closerst to the Sun
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn,
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2.
    The function should return a tuple containing all planets whose orbits are
    located between the orbit of planet1 and the orbit of planet2, sorted by
    the proximity to the sun.
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names.
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    """

    planet_names = (
        "Mercury",
        "Venus",
        "Earth",
        "Mars",
        "Jupiter",
        "Saturn",
        "Uranus",
        "Neptune",
    )
    if (
        planet1 not in planet_names
        or planet2 not in planet_names
        or planet1 == planet2
    ):
        return ()
    planet1_index = planet_names.index(planet1)
    planet2_index = planet_names.index(planet2)
    if planet1_index < planet2_index:
        return planet_names[planet1_index + 1 : planet2_index]
    else:
        return planet_names[planet2_index + 1 : planet1_index]


# States that all items in the return value are planet names ('Mercury',
# 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune'), and that
# planet1 must be found in the return value or be an invalid planet, and planet2
# must be found in the return value or be an invalid planet. It also confirms that
# each planet in the return value follows the previous planet in the planet_names
# list and every planet in the return value falls between planet1 and planet2
# based on their index in the list of valid planets.

assert (
    all(
        planet
        in [
            "Mercury",
            "Venus",
            "Earth",
            "Mars",
            "Jupiter",
            "Saturn",
            "Uranus",
            "Neptune",
        ]
        for planet in return_value
    )
    and (
        planet1 in return_value
        or planet1
        not in [
            "Mercury",
            "Venus",
            "Earth",
            "Mars",
            "Jupiter",
            "Saturn",
            "Uranus",
            "Neptune",
        ]
    )
    and (
        planet2 in return_value
        or planet2
        not in [
            "Mercury",
            "Venus",
            "Earth",
            "Mars",
            "Jupiter",
            "Saturn",
            "Uranus",
            "Neptune",
        ]
    )
    and all(
        return_value[i]
        in [
            "Mercury",
            "Venus",
            "Earth",
            "Mars",
            "Jupiter",
            "Saturn",
            "Uranus",
            "Neptune",
        ][
            [
                "Mercury",
                "Venus",
                "Earth",
                "Mars",
                "Jupiter",
                "Saturn",
                "Uranus",
                "Neptune",
            ].index(return_value[i - 1])
            + 1 :
        ]
        for i in range(1, len(return_value))
    )
)
