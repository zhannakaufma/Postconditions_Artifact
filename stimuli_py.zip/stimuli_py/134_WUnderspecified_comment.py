def check_if_last_char_is_a_letter(txt):
    """
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False
    """

    check = txt.split(" ")[-1]
    return (
        True if len(check) == 1 and (97 <= ord(check.lower()) <= 122) else False
    )


# Ensures that the return value is consistent with the condition that the last
# character in the text is a letter and the text is either of length 1 or the
# character before the last one is a space.

assert (
    return_value == (txt[-1].isalpha() and (len(txt) == 1 or txt[-2] == " "))
    if txt
    else False
)
