def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """

    for i, l1 in enumerate(l):
        for j in range(i + 1, len(l)):
            if l1 + l[j] == 0:
                return True
    return False


# POSTCONDITION ASSERT: If both the return value is True and there exists at
# least one element and its negation in the input list, or if the return value is
# False and there are no elements and their negations that sum to zero in the
# input list, then the postcondition is satisfied.

assert (return_value == True and any(-i in l for i in l)) or (
    return_value == False and not any(-i in l for i in l)
)
