def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# POSTCONDITION ASSERT: For the list to be divided into two halves, the median
# separates the list such that one half contains more elements than the other half

assert (
    sum(i <= return_value for i in l) >= len(l) // 2
    and sum(i >= return_value for i in l) >= len(l) // 2
)
