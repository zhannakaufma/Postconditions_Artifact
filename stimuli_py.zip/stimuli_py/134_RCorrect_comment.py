def check_if_last_char_is_a_letter(txt):
    """
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False
    """

    check = txt.split(" ")[-1]
    return (
        True if len(check) == 1 and (97 <= ord(check.lower()) <= 122) else False
    )


# The return value should be False if the last character of the input text is
# not a letter or if the text has more than one character and the second to last
# character is not a space.

assert not return_value or (
    txt[-1].isalpha() and (len(txt) == 1 or txt[-2] == " ")
)
