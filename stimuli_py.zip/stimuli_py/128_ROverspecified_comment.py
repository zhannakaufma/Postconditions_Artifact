def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    if not arr:
        return None
    prod = 0 if 0 in arr else (-1) ** len(list(filter(lambda x: x < 0, arr)))
    return prod * sum([abs(i) for i in arr])


# Postcondition: Checks that the return value is None if the array is empty,
# otherwise it checks that the return value is an integer which is the product of
# the array's signs multiplied by the sum of their absolute values.

assert (isinstance(return_value, int) and len(arr) > 0) or (
    return_value is None and len(arr) == 0
)
