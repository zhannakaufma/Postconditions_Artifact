def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# Ensures that all elements in the return value are present in both lists l1 and
# l2, and that the return value is a sorted list of unique elements.

assert all(
    i in l1 and i in l2 for i in return_value
) and return_value == sorted(set(return_value))
