def encode(message):
    """
    Write a function that takes a message, and encodes in such a
    way that it swaps case of all letters, replaces all vowels in
    the message with the letter that appears 2 places ahead of that
    vowel in the english alphabet.
    Assume only letters.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return "".join([vowels_replace[i] if i in vowels else i for i in message])


# Assert that the encoding function correctly swaps the case of all letters in
# the input message and replaces vowels with the appropriate letter 2 places ahead
# in the alphabet, and the length of the return_value is equal to the length of
# the input message. Raise a postcondition error if this is not the case.

assert all(
    (c.lower() not in "aeiou" and rv == c.swapcase())
    or (
        c.lower() in "aeiou"
        and rv
        == string.ascii_letters[string.ascii_letters.find(c.swapcase()) + 2]
    )
    for c, rv in zip(message, return_value)
)
