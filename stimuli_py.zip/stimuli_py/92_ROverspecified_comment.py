def any_int(x, y, z):
    """
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and
    all numbers are integers.
    Returns false in any other cases.

    Examples
    any_int(5, 2, 7) ➞ True

    any_int(3, 2, 2) ➞ False

    any_int(3, -2, 1) ➞ True

    any_int(3.6, -2.2, 2) ➞ False
    """

    if isinstance(x, int) and isinstance(y, int) and isinstance(z, int):
        if (x + y == z) or (x + z == y) or (y + z == x):
            return True
        return False
    return False


# Asserts that the return value is True if and only if x, y, and z are all
# integers and satisfy the condition x+y=z or y+z=x or z+x=y.

assert (return_value == True) <= (
    (x == y + z or y == x + z or z == x + y)
    and all(isinstance(i, int) for i in [x, y, z])
), "Postcondition failed"
