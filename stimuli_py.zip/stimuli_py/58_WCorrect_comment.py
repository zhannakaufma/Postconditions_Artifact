def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """

    ret = set()
    for e1 in l1:
        for e2 in l2:
            if e1 == e2:
                ret.add(e1)
    return sorted(list(ret))


# This postcondition checks that the return value is a sorted list of unique
# common elements between l1 and l2, where each element appears exactly once in
# l1. An assertion error will be raised if this condition is not met.

assert return_value == sorted(
    [value for value in l1 if value in l2 and return_value.count(value) == 1]
)
