def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """

    if x > y:
        return -1
    if y % 2 == 0:
        return y
    if x == y:
        return -1
    return y - 1


# The postcondition assert checks the following conditions: If x is greater than
# y, the returned value should be -1.  If the return value is the largest even
# number within the range of x and y (inclusive), then the condition is also
# satisfied. In other words, if the value of y is an even number and x does not
# exceed y,  then y is returned as it satisfies the assert condition.

assert (return_value % 2 == 0 and x <= return_value <= y) or (
    x > y and return_value == -1
)
