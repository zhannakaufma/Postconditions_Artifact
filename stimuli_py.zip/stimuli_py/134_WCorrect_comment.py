def check_if_last_char_is_a_letter(txt):
    """
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False
    """

    check = txt.split(" ")[-1]
    return (
        True if len(check) == 1 and (97 <= ord(check.lower()) <= 122) else False
    )


# The function should return True if the last character of the input string is
# an alphabetical character and not part of a word (i.e. it is the only character
# in the string or is preceded by a space), and False otherwise. If the input
# string is empty, the postcondition fails.

assert (
    return_value == (txt[-1].isalpha() and (len(txt) == 1 or txt[-2] == " "))
    if txt
    else False
)
