def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Assert that the function returns True if the list is in non-decreasing order
# or in non-increasing order, and False otherwise

assert (
    all(l[i] <= l[i + 1] for i in range(len(l) - 1))
    or all(l[i] >= l[i + 1] for i in range(len(l) - 1))
) == return_value
