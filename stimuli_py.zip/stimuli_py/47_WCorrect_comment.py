def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l = sorted(l)
    if len(l) % 2 == 1:
        return l[len(l) // 2]
    else:
        return (l[len(l) // 2 - 1] + l[len(l) // 2]) / 2.0


# Checks if the count of the median value in the list is 1, and that the number
# of elements less than the median is equal to the number of elements greater than
# the median. Otherwise, ensures that the number of elements in 'l' that are less
# than or equal to the return value equals the number of elements that are greater
# than or equal to the return value

assert (
    l.count(return_value) == 1
    and len([i for i in l if i < return_value])
    == len([i for i in l if i > return_value])
) or (
    len([i for i in l if i <= return_value])
    == len([i for i in l if i >= return_value])
)
