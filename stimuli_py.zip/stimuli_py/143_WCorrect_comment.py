def words_in_sentence(sentence):
    """
    You are given a string representing a sentence, the sentence contains some
    words separated by a space, and you have to return a string that contains
    the words from the original sentence, whose lengths are prime numbers, the
    order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    new_lst = []
    for word in sentence.split():
        flg = 0
        if len(word) == 1:
            flg = 1
        for i in range(2, len(word)):
            if len(word) % i == 0:
                flg = 1
        if flg == 0 or len(word) == 2:
            new_lst.append(word)
    return " ".join(new_lst)


# Only words with lengths of 2, 3, 5, or 7 are allowed in the return value, and
# each of these words should exist in the original sentence.

assert all(len(word) in [2, 3, 5, 7] for word in return_value.split()) and all(
    word in sentence for word in return_value.split()
)
