def max_fill(grid, capacity):
    import math

    """
    You are given a rectangular grid of wells. Each row represents a single
    well, and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from
    it, and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input:
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input:
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5

    Example 3:
        Input:
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """

    return sum([math.ceil(sum(arr) / capacity) for arr in grid])


# Ensure that the return value is calculated by summing up the water in each
# well, dividing by the bucket capacity, and rounding down to determine the number
# of bucket operations needed

assert (
    isinstance(return_value, int)
    and return_value >= 0
    and return_value <= sum(map(sum, grid)) / capacity
)
