def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    return [n + 2 * i for i in range(n)]


# The return value must have a length of n, the first element must be n, and
# each subsequent element must be either the previous element plus 1 or plus 2
# depending on the index of the element.

assert (
    len(return_value) == n
    and return_value[0] == n
    and all(
        return_value[i] == return_value[i - 1] + (2 if i % 2 == n % 2 else 1)
        for i in range(1, n)
    )
)
