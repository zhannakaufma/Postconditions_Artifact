def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.

    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    odd_digit_elements = []
    for i in x:
        if all(int(c) % 2 == 1 for c in str(i)):
            odd_digit_elements.append(i)
    return sorted(odd_digit_elements)


# The postcondition assert checks that all elements in the returned list are
# numbers with unique digits in ascending order, and all of their digits are odd.

assert all(
    str(i) == "".join(sorted(str(i))) and all(int(d) % 2 != 0 for d in str(i))
    for i in return_value
)
