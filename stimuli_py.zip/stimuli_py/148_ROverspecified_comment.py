def bf(planet1, planet2):
    """
    There are eight planets in our solar system: the closerst to the Sun
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn,
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2.
    The function should return a tuple containing all planets whose orbits are
    located between the orbit of planet1 and the orbit of planet2, sorted by
    the proximity to the sun.
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names.
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    """

    planet_names = (
        "Mercury",
        "Venus",
        "Earth",
        "Mars",
        "Jupiter",
        "Saturn",
        "Uranus",
        "Neptune",
    )
    if (
        planet1 not in planet_names
        or planet2 not in planet_names
        or planet1 == planet2
    ):
        return ()
    planet1_index = planet_names.index(planet1)
    planet2_index = planet_names.index(planet2)
    if planet1_index < planet2_index:
        return planet_names[planet1_index + 1 : planet2_index]
    else:
        return planet_names[planet2_index + 1 : planet1_index]


# This postcondition checks that all elements in the return tuple are valid
# planet names, and that the first and last elements are not equal to planet1 and
# planet2 respectively. It verifies that the function correctly includes only
# planets between planet1 and planet2, and excludes the input planets themselves.

assert (
    all(
        planet
        in [
            "Mercury",
            "Venus",
            "Earth",
            "Mars",
            "Jupiter",
            "Saturn",
            "Uranus",
            "Neptune",
        ]
        for planet in return_value
    )
    and (planet1 != return_value[0] if return_value else True)
    and (planet2 != return_value[-1] if return_value else True)
)
