def encode(message):
    """
    Write a function that takes a message, and encodes in such a
    way that it swaps case of all letters, replaces all vowels in
    the message with the letter that appears 2 places ahead of that
    vowel in the english alphabet.
    Assume only letters.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    vowels = "aeiouAEIOU"
    vowels_replace = dict([(i, chr(ord(i) + 2)) for i in vowels])
    message = message.swapcase()
    return "".join([vowels_replace[i] if i in vowels else i for i in message])


# This postcondition checks if all the uppercase letters in the input message
# are converted to lowercase and vice versa in the return_value. This is done by
# comparing the original letter and the corresponding letter in the return_value
# after both have been converted to lowercase.

assert all(m.lower() != r.lower() for m, r in zip(message, return_value))
