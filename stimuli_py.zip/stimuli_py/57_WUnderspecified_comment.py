def monotonic(l: list):
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """

    if l == sorted(l) or l == sorted(l, reverse=True):
        return True
    return False


# Checks that the elements in the input list 'l' are strictly increasing if the
# function returns True

assert all(
    (b - a > 0 for a, b in zip(l, l[1:]))
    if return_value
    else (b - a <= 0 for a, b in zip(l, l[1:]))
)
