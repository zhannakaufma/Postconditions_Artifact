def match_parens(lst):
    """
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No'
    otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    """

    def check(s):
        val = 0
        for i in s:
            if i == "(":
                val = val + 1
            else:
                val = val - 1
            if val < 0:
                return False
        return True if val == 0 else False

    S1 = lst[0] + lst[1]
    S2 = lst[1] + lst[0]
    return "Yes" if check(S1) or check(S2) else "No"


# Ensure that the return value is either 'Yes' or 'No', and that the
# concatenation of the two input strings will result in a balanced parentheses
# string. If the return value is 'Yes' then all counts of open and close
# parentheses in the first string of the input list is equal to that of the second
# string, or if the return value is 'No' then not all counts of open and close
# parentheses in the first string of the input list is equal to that of the second
# string.

assert (return_value in ["Yes", "No"]) and (
    (
        return_value == "Yes"
        and all(lst[0].count(c) == lst[1].count(c) for c in ["(", ")"])
    )
    or (
        return_value == "No"
        and not all(lst[0].count(c) == lst[1].count(c) for c in ["(", ")"])
    )
)
