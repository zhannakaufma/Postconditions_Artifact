def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Asserts that the return value is True if the length of the string is a prime
# number, or False if it is not, while also ensuring the string length is greater
# than 1.

assert (
    return_value
    and all(len(string) % i for i in range(2, int(len(string) ** 0.5) + 1))
    and len(string) > 1
) or (
    not return_value
    and not all(len(string) % i for i in range(2, int(len(string) ** 0.5) + 1))
)
