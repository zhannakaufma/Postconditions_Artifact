def right_angle_triangle(a, b, c):
    """
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    """

    return (
        a * a == b * b + c * c
        or b * b == a * a + c * c
        or c * c == a * a + b * b
    )


# Verifies whether the return value is True, and in that case, c squared should
# be equal to the sum of squares of a and b. Otherwise, the return value must be
# False, and c squared should not be equal to the sum of squares of a and b.

assert (return_value == True and c**2 == a**2 + b**2) or (
    return_value == False and c**2 != a**2 + b**2
)
