def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# Ensure that the return value is True and the length of the string has no
# divisors other than 1 and itself, or the length is not 1. Otherwise, the return
# value is False.

assert (
    return_value
    and all(len(string) % i for i in range(2, int(len(string) ** 0.5) + 1))
    and len(string) > 1
) or not return_value
