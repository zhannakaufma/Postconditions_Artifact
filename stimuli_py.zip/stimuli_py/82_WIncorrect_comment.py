def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """

    l = len(string)
    if l == 0 or l == 1:
        return False
    for i in range(2, l):
        if l % i == 0:
            return False
    return True


# The return value must be True and all lengths of a substring of the input
# string divided by numbers from 2 to the square root of the input string length
# must have a remainder greater than 0, and the input string length must be
# greater than 1 if the return value is True; otherwise, the return value must be
# False and not all lengths of a substring of the input string divided by numbers
# from 2 to the square root of the input string length must have a remainder
# greater than 0.

assert (
    return_value
    and all(len(string) % i for i in range(2, int(len(string) ** 0.5) + 1))
    and len(string) > 1
) or (
    not return_value
    and not all(len(string) % i for i in range(2, int(len(string) ** 0.5) + 1))
)
