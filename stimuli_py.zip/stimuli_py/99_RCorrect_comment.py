def closest_integer(value):
    """
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    """

    from math import floor, ceil

    if value.count(".") == 1:
        # remove trailing zeros
        while value[-1] == "0":
            value = value[:-1]

    num = float(value)
    if value[-2:] == ".5":
        if num > 0:
            res = ceil(num)
        else:
            res = floor(num)
    elif len(value) > 0:
        res = int(round(num))
    else:
        res = 0

    return res


# Checks if the return value is an integer and that the absolute difference
# between the input value as a float and the return value does not exceed 0.5. It
# further ensures that the absolute difference between the input value as a float
# and its rounded form is not exactly 0.5, or the absolute value of the return
# value is at least as large as the absolute value of the rounded input.

assert (
    type(return_value) == int
    and abs(float(value) - return_value) <= 0.5
    and (
        abs(float(value) - round(float(value))) != 0.5
        or abs(return_value) >= abs(round(float(value)))
    )
)
