def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace, if no
    whitespaces exists in the text you should split on commas ',' if no commas
    exists you should return the number of lower-case letters with odd order in
    the alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3
    """

    if " " in txt:
        return txt.split()
    elif "," in txt:
        return txt.replace(",", " ").split()
    else:
        return len([i for i in txt if i.islower() and ord(i) % 2 == 0])


# Assert that the return value is a list if the input string contains either a
# whitespace or a comma, otherwise assert that the return value is an integer.

assert (
    isinstance(return_value, list)
    if " " in txt or "," in txt
    else isinstance(return_value, int)
)
